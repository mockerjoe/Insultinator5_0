from .Insultinator5_0 import *

__doc__ = Insultinator5_0.__doc__
if hasattr(Insultinator5_0, "__all__"):
    __all__ = Insultinator5_0.__all__